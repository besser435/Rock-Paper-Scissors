# Rock-Paper-Scissors
Before I moved to GitHub I just had different files for the different versions. Those are in the Old folder.
The GUI folder was an attempt to make a GUI version, but I just don't know enough at this point to pull it off.
The short version is just the most simple form of this game, none of the extra features.

Right now the audio files won't work, as they are for the arcade version. They will work one PyGame is implimented.

TO DO LIST:
Move music over to PyGame instead of winsound
Add ability to enter a letter instead of the full word
Add a way of replaying or going to menu when game ends
Make an even more rigged version so the comp will always win. Right now it just leans towards rock
Spellcheck everything. Asteroid is really bunged up

The arcade game version has a few features that should be moved over to this version
